// Updated register.tsx with Auth0 Signup Integration
import { useState } from 'react';
import { 
  View, Text, StyleSheet, TextInput, TouchableOpacity,
  KeyboardAvoidingView, Platform, ScrollView, Alert, Image
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { useRouter } from 'expo-router';
import { User, ArrowLeft } from 'lucide-react-native';
import * as ImagePicker from 'expo-image-picker';
import auth0 from '../../utils/auth0';

import { validateRegistrationForm } from '../../utils/validation';

export default function Auth0SignUpScreen() {
  const router = useRouter();
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    phone: '',
    address: '',
    profilePhoto: '',
    idProof: ''
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);

  const updateFormData = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const pickImage = async (field: 'profilePhoto' | 'idProof') => {
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      quality: 0.8,
    });
    if (!result.canceled && result.assets && result.assets.length > 0) {
      updateFormData(field, result.assets[0].uri);
    }
  };

  const handleAuth0SignUp = async () => {
    setErrors({});
    const validation = validateRegistrationForm(formData);
    if (!validation.isValid) {
      setErrors(validation.errors);
      return;
    }
    setLoading(true);
    try {
      const credentials = await auth0.webAuth.authorize({
        scope: 'openid profile email',
        audience: 'https://' + auth0.domain + '/userinfo'
      });

      if (credentials?.accessToken) {
        Alert.alert('Success', 'Signed up with Auth0!');
        router.replace('/create-profile');
      }
    } catch (error: any) {
      Alert.alert('Error', error.message || 'Sign up failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={styles.keyboardView}>
        <ScrollView showsVerticalScrollIndicator={false}>
          <View style={styles.header}>
            <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
              <ArrowLeft size={24} color="#2563EB" />
            </TouchableOpacity>
            <Text style={styles.title}>Sign Up with Auth0</Text>
            <Text style={styles.subtitle}>Secure sign up powered by Auth0</Text>
          </View>

          <View style={styles.form}>
            <View style={styles.inputContainer}>
              <Text style={{ marginBottom: 8, color: '#6B7280' }}>Profile Picture (optional)</Text>
              {formData.profilePhoto && (
                <>
                  <Image source={{ uri: formData.profilePhoto }} style={{ width: 80, height: 80, borderRadius: 40, marginBottom: 8 }} />
                  <TouchableOpacity style={[styles.socialButton, { backgroundColor: '#F87171', marginBottom: 8 }]} onPress={() => updateFormData('profilePhoto', '')}>
                    <Text style={[styles.socialButtonText, { color: 'white' }]}>Remove Photo</Text>
                  </TouchableOpacity>
                </>
              )}
              <TouchableOpacity style={styles.socialButton} onPress={() => pickImage('profilePhoto')}>
                <Text style={styles.socialButtonText}>{formData.profilePhoto ? 'Change Photo' : 'Pick a Photo'}</Text>
              </TouchableOpacity>
            </View>

            <View style={styles.row}>
              <View style={[styles.inputContainer, styles.halfWidth]}>
                <View style={styles.inputWrapper}>
                  <User size={20} color="#6B7280" style={styles.inputIcon} />
                  <TextInput
                    style={styles.input}
                    placeholder="First name"
                    placeholderTextColor="#000000"
                    value={formData.firstName}
                    onChangeText={(value) => updateFormData('firstName', value)}
                    autoCapitalize="words"
                  />
                </View>
              </View>

              <View style={[styles.inputContainer, styles.halfWidth]}>
                <View style={styles.inputWrapper}>
                  <User size={20} color="#6B7280" style={styles.inputIcon} />
                  <TextInput
                    style={styles.input}
                    placeholder="Last name"
                    placeholderTextColor="#000000"
                    value={formData.lastName}
                    onChangeText={(value) => updateFormData('lastName', value)}
                    autoCapitalize="words"
                  />
                </View>
              </View>
            </View>

            <View style={styles.inputContainer}>
              <TextInput
                style={styles.input}
                placeholder="Phone"
                placeholderTextColor="#000"
                value={formData.phone}
                onChangeText={(value) => updateFormData('phone', value)}
                keyboardType="phone-pad"
              />
            </View>

            <View style={styles.inputContainer}>
              <TextInput
                style={styles.input}
                placeholder="Address"
                placeholderTextColor="#000"
                value={formData.address}
                onChangeText={(value) => updateFormData('address', value)}
              />
            </View>

            <View style={styles.inputContainer}>
              <Text style={{ marginBottom: 8, color: '#6B7280' }}>Identification Proof</Text>
              {formData.idProof && (
                <Image source={{ uri: formData.idProof }} style={{ width: 80, height: 80, borderRadius: 8, marginBottom: 8 }} />
              )}
              <TouchableOpacity style={styles.socialButton} onPress={() => pickImage('idProof')}>
                <Text style={styles.socialButtonText}>{formData.idProof ? 'Change ID Proof' : 'Upload ID Proof'}</Text>
              </TouchableOpacity>
            </View>

            <TouchableOpacity style={styles.registerButton} onPress={handleAuth0SignUp} disabled={loading}>
              <LinearGradient colors={["#2563EB", "#3B82F6"]} style={styles.registerButtonGradient}>
                <Text style={styles.registerButtonText}>{loading ? 'Signing Up...' : 'Sign Up with Auth0'}</Text>
              </LinearGradient>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#FFFFFF' },
  keyboardView: { flex: 1 },
  header: { paddingHorizontal: 24, paddingTop: 12, paddingBottom: 32 },
  backButton: { width: 44, height: 44, borderRadius: 22, backgroundColor: '#F3F4F6', justifyContent: 'center', alignItems: 'center', marginBottom: 24 },
  title: { fontSize: 32, fontWeight: 'bold', color: '#111827', marginBottom: 8 },
  subtitle: { fontSize: 16, color: '#6B7280' },
  form: { paddingHorizontal: 24 },
  row: { flexDirection: 'row', gap: 12 },
  inputContainer: { marginBottom: 20 },
  halfWidth: { flex: 1 },
  inputWrapper: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#F9FAFB', borderRadius: 12, borderWidth: 1, borderColor: '#E5E7EB', paddingHorizontal: 16 },
  inputIcon: { marginRight: 12 },
  input: { flex: 1, paddingVertical: 16, fontSize: 16, color: '#111827' },
  registerButton: { marginBottom: 24, marginTop: 12 },
  registerButtonGradient: { paddingVertical: 16, borderRadius: 12, alignItems: 'center' },
  registerButtonText: { fontSize: 18, fontWeight: '600', color: 'white' },
  socialButton: { backgroundColor: '#F9FAFB', borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 12, paddingVertical: 16, alignItems: 'center', marginBottom: 12 },
  socialButtonText: { fontSize: 16, color: '#374151' },
});
